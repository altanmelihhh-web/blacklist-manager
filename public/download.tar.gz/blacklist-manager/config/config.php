<?php
/**
 * Blacklist Manager - Configuration File
 * This is a working configuration - customize as needed
 */

return [
    'database' => [
        'enabled' => false
    ],

    'app' => [
        'name' => 'Blacklist Manager',
        'timezone' => 'UTC',
        'debug' => true,
        'max_upload_size' => 5242880,
        'allowed_logo_types' => ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml']
    ],

    'instance_mode' => 'multi',

    'instances' => [
        [
            'id' => 'prod',
            'name' => 'Production',
            'slug' => 'production',
            'logo' => '',
            'enabled' => true,
            'description' => 'Production environment blacklist management',
            'protected_blocks' => [
                '10.0.0.0/8',
                '172.16.0.0/12',
                '192.168.0.0/16',
                '127.0.0.0/8'
            ],
            'custom_protected' => [],
            'data_dir' => __DIR__ . '/../data/prod',
            'blacklist_file' => 'blacklist.txt',
            'whitelist_file' => 'whitelist.txt',
            'output_file' => 'output_blacklist.txt'
        ],
        [
            'id' => 'staging',
            'name' => 'Staging',
            'slug' => 'staging',
            'logo' => '',
            'enabled' => true,
            'description' => 'Staging environment blacklist management',
            'protected_blocks' => [
                '10.0.0.0/8',
                '172.16.0.0/12',
                '192.168.0.0/16',
                '127.0.0.0/8'
            ],
            'custom_protected' => [],
            'data_dir' => __DIR__ . '/../data/staging',
            'blacklist_file' => 'blacklist.txt',
            'whitelist_file' => 'whitelist.txt',
            'output_file' => 'output_blacklist.txt'
        ]
    ],

    'default_sources' => [
        [
            'name' => 'CI Badguys',
            'url' => 'https://raw.githubusercontent.com/firehol/blocklist-ipsets/master/ci_badguys.ipset',
            'enabled' => true,
            'type' => 'ipset',
            'update_interval' => 86400,
            'description' => 'Known bad IPs from CI Army'
        ],
        [
            'name' => 'FireHOL Level1',
            'url' => 'https://raw.githubusercontent.com/firehol/blocklist-ipsets/master/firehol_level1.netset',
            'enabled' => true,
            'type' => 'netset',
            'update_interval' => 86400,
            'description' => 'FireHOL Level 1 - Most reliable threats'
        ]
    ],

    'cron' => [
        'enabled' => true,
        'log_file' => __DIR__ . '/../data/cron.log',
        'lock_file' => __DIR__ . '/../data/cron.lock',
        'max_execution_time' => 300
    ],

    'session' => [
        'name' => 'BL_MANAGER_SESS',
        'lifetime' => 7200,
        'path' => '/',
        'secure' => false,
        'httponly' => true
    ],

    'security' => [
        'csrf_protection' => true,
        'allowed_hosts' => [],
        'rate_limit' => [
            'enabled' => false,
            'max_requests' => 100,
            'time_window' => 60
        ]
    ],

    'export' => [
        'excel_template' => __DIR__ . '/../data/template.xlsx',
        'formats' => ['txt', 'csv', 'json', 'xlsx']
    ],

    'ui' => [
        'items_per_page' => [10, 25, 50, 100],
        'default_items_per_page' => 25,
        'theme' => 'default',
        'show_footer' => true,
        'footer_text' => '© 2024 Blacklist Manager. Open Source Project.'
    ]
];
